<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "regemp";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $name = $_POST['name'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); 
    $gender = $_POST['gender'];
    $department = $_POST['department'];
    $position = $_POST['position'];
    $salary = $_POST['salary'];
    $joindate = $_POST['joindate'];

    
    $stmt = $conn->prepare("INSERT INTO users (name, address, email, password, gender, department, position, salary, joindate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssss", $name, $address, $email, $password, $gender, $department, $position, $salary, $joindate);

    
    if ($stmt->execute() === TRUE) {
        echo '
<div class="popup" id="popup">
    <ion-icon name="checkmark-circle-outline"></ion-icon>
    <h2>Thank you!</h2>
    <p>Your submission was successful. <br>Thanks!</p>
    <a href="Login.html"><button onclick="CloseSlide()">OK</button></a>
</div>

<style>
    .popup {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 300px;
        padding: 20px;
        border: 2px solid green;
        border-radius: 10px;
        background-color: #f9f9f9;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        text-align: center;
        z-index: 1000;
    }
    .popup ion-icon {
        font-size: 50px;
        color: green;
    }
    .popup h2 {
        margin: 10px 0;
        font-size: 24px;
        color: #333;
    }
    .popup p {
        font-size: 18px;
        color: #666;
        margin-bottom: 20px;
    }
    .popup button {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background-color: green;
        color: white;
        font-size: 16px;
        cursor: pointer;
    }
    .popup button:hover {
        background-color: darkgreen;
    }
</style>
';
    } else {
        echo "Error: " . $stmt->error;
    }

    
    $stmt->close();
}


$conn->close();
?>
